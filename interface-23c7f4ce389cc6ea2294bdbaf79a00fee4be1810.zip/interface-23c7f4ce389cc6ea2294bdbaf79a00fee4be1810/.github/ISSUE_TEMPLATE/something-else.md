---
name: Something Else
about: Tell us something else
title: ''
labels: ''
assignees: ''
---

<!-- 
DO NOT CREATE A TOKEN LISTING REQUEST IN THIS REPOSITORY.
YOUR ISSUE WILL BE DELETED. 
SEE https://github.com/Uniswap/default-token-list#adding-a-token

IF YOU NEED SUPPORT, JOIN THE DISCORD: https://discord.com/invite/EwFs3Pp
-->



